import java.util.HashMap;

class Main {
	//Only relevant for debugging
	public static void printArr(int[][] a)
	{
		for (int i = 0; i<a.length; i++)
			{
				for (int j = 0; j<a[i].length; j++)
					{
						System.out.print(a[i][j]+" ");
					}
				System.out.println();
			}
		System.out.println();
	}
	//Overloaded debugging
	public static void printArr(double[][] a)
	{
		for (int i = 0; i<a.length; i++)
			{
				for (int j = 0; j<a[i].length; j++)
					{
						System.out.print(a[i][j]+" ");
					}
				System.out.println();
			}
		System.out.println();
	}
	//Multiply two matrices 
	//This might not work for two differently sized arrays
	//Only used for two square arrays in this, so works for its usage
	public static double[][] matrixMult(double[][] a, double[][] b) {
		double[][] c = new double[a.length][a.length];

		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				for (int k = 0; k < b.length; k++)
					c[i][j] += a[i][k] * b[k][j];
			}
		}

		return c;
	}
	//This swaps the rows row1 and row2
	//Also swaps the indeces at index row1 and row2
	//This is because the indeces refer to rows
	public static int [][] swapRows(int[][] a, int row1, int row2)
	{
		
		int [] tempRow = new int [a.length];
		for (int i = 0; i<a.length; i++)
			{
				tempRow[i] = a[row2][i];
			}

		a[row2] = a[row1];
		a[row1] = tempRow;

		for (int i = 0; i<a.length; i++)
			{
				int tempV = a[i][row2];
				a[i][row2] = a[i][row1];
				a[i][row1] = tempV;
			}

		return a;
	}
	//Overloaded swapRows for double[][]
	public static double [][] swapRows(double[][] a, int row1, int row2)
	{
		
		double [] tempRow = new double [a.length];
		for (int i = 0; i<a.length; i++)
			{
				tempRow[i] = a[row2][i];
			}

		a[row2] = a[row1];
		a[row1] = tempRow;

		for (int i = 0; i<a.length; i++)
			{
				double tempV = a[i][row2];
				a[i][row2] = a[i][row1];
				a[i][row1] = tempV;
			}

		return a;
	}
	//Swapping indeces
	public static double [] swapIndeces(double [] a, int index1, int index2)
	{
		double tempDouble = a[index2];
		a[index2] = a[index1];
		a[index1] = tempDouble;

		return a;
	}

	public static void main(String[] args) {
		//Given a n x n array of nonnegative integers, each integer representing a probability of reaching the row that corresponds to its index in its respective row, find the probability of reaching each innescapable row after infinite time (rows that are all 0) represented as integers with a common denominator

		
		//Initial array
		int[][] m = {
			{0,2,0,0,2,5},
			{3,0,5,7,0,0},
			{0,4,1,2,0,0},
			{0,0,0,0,0,0},
			{0,0,0,0,0,0},
			{0,0,0,0,0,0},
		};

		
		//Useful for outputting the answer later
		HashMap <Integer,Integer> swapped = new HashMap<Integer,Integer>();

		//This tests which rows are terminal (they cannot be exited)
		boolean [] termStates = new boolean [m.length];

		for (int i = 0; i<termStates.length; i++)
			{
				termStates[i] = true;
			}
		
		for (int i = 0; i<m.length; i++)
			{
				for (int j = 0; j<m[i].length; j++)
					{
						if (m[i][j] != 0)
						{
							termStates[i] = false;
						}
					}
			}

		//If the first row is terminal, it creates the terminal 0 row array
		if (termStates[0])
		{
			int termStateCounter = 0;
			for (int i = 0; i<termStates.length; i++)
				{
					if (termStates[i])
					{
						termStateCounter++;
					}
				}
			int [] solution = new int[termStateCounter+1];
			solution[termStateCounter] = 1;
			solution[0] = 1;
		}
		
		//Reorders the array so that non-terminal states come first all the time
		for (int i = 0; i<termStates.length; i++)
			{
				if (!termStates[i])
				{
					for (int j = 0; j<i; j++)
						{
							boolean done = false;
							if (termStates[j] && !done)
							{
								m = swapRows(m, i, j);
								done = true;
							}
						}
				}
			}

		
		//Reassessing term states
		for (int i = 0; i<termStates.length; i++)
			{
				termStates[i] = true;
			}

		for (int i = 0; i<m.length; i++)
			{
				for (int j = 0; j<m[i].length; j++)
					{
						if (m[i][j] != 0)
						{
							termStates[i] = false;
						}
					}
			}

		
		//Interpretation change (consistent with absorbing Markov chains)
		for (int i = 0; i<m.length; i++)
			{
				if (termStates[i])
				{
					m[i][i] = 1;
				}
			}

		
		//This array is extremely useful
		//Allows us to convert the matrix to doubles and standard markov chain form
		double [][] mD = new double [m.length][m.length];

		for (int i = 0; i<m.length; i++)
			{
				for (int j = 0; j<m.length; j++)
					{
						mD[i][j] = m[i][j];
					}
			}

		
		//Dividing all the individual numbers by their row sum (for standardization)
		int [] rowSums = new int [m.length];

		for (int i = 0; i<m.length; i++)
			{
				for (int j = 0; j<m.length; j++)
					{
						rowSums[i] += mD[i][j];
					}
			}

		for (int i = 0; i<m.length; i++)
			{
				for (int j = 0; j<m.length; j++)
					{
						mD[i][j] /= rowSums[i];
					}
			}

		//This may seem useless, but it is used to preserve the original array (for power raising)
		double[][] mDm = mD;

		
		//Raise the matrix to a very high power
		//For some reason at powers past some number, it causes some errors
		//This is possibly because of decimal rounding errors that would not happen with a manual calculation using exact fractional values
		for (int i = 0; i < 100000; i++) {
			double [][] mDm2 = mDm;
			mDm = matrixMult(mDm, mD);

			boolean d = true;

			for (int j = 0; j<mDm.length; j++)
				{
					for (int k = 0; k<mDm[j].length; k++)
						{
							if (mDm[j][k] != mDm2[j][k])
							{
								d = false;
							}
						}
				}

			if (d)
			{
				break;
			}
		}
		
		//A pre-array for the non-multiplied solution array
		double [] sPre = new double [m.length];

		//Swapping it back
		for (HashMap.Entry<Integer,Integer> entry : swapped.entrySet())
			{
				int ind1 = entry.getKey();
				int ind2 = entry.getValue();

				mDm[0] = swapIndeces(mDm[0], ind1, ind2);
				
			}

		for (HashMap.Entry<Integer,Integer> entry : swapped.entrySet())
			{
				int row1 = entry.getKey();
				int row2 = entry.getValue();

				mDm = swapRows(mDm, row1, row2);
			}

		//mDm[0] represents the probabilites from starting at row 0 (what is relevant to the problem)
		sPre = mDm[0];

		int c = 0;

		//Counting termStates

		for (int i = 0; i<termStates.length; i++)
			{
				if (termStates[i])
				{
					c++;
				}
			}

		
		//Moving from sPre to s, taking only the numbers representing terminal states
		double [] s = new double [c];

		int c2 = 0;
		for (int i = 0; i<m.length; i++)
			{
				if (termStates[i])
				{
					s[c2] = sPre[i];
					c2++;
				}
			}
		
		//Tests to find the common denominator
		boolean complete = false;
		int denom = 0;

		for (int i = 1; i < Integer.MAX_VALUE; i++) {
			for (int j = 0; j < s.length; j++) {
				double sT = (s[j] * i);
				double sR = Math.round(s[j]*i);
				//Some error tolerance is necessary because of decimal rounding errors
				boolean epic = Math.abs(sR-sT) < 0.000001;
				if (epic) {
					complete = true;
				}
			}
			//Testing false after testing true because if one number is false, the entire thing is incorrect, therefore we need to test all true, and then all false
			//If we were to test one true, one false, the last number being true would make everything true
			for (int j = 0; j < s.length; j++) {
				double sT = (s[j] * i);
				double sR = Math.round(s[j]*i);
				//Same situation as above
				boolean epic = Math.abs(sR-sT) < 0.000001;
				if (!epic) {
					complete = false;
				}
			}

			if (complete) {
				//Records the number
				denom = i;
				break;
			}
		}

		//Final solution array
		int[] solution = new int[s.length + 1];
		solution[s.length] = denom;
		for (int i = 0; i < s.length; i++) {
			solution[i] = (int) Math.round(s[i] * denom);
		}

		for (int i = 0; i < solution.length; i++) {
			System.out.print(solution[i] + " ");
		}
		
	}
}